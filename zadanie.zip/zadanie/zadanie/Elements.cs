﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarathonSkills
{
    public class Elements
    {
        public string Name { get; set; }
        public int TypeA { get; set; }
        public int TypeB { get; set; }
        public int TypeC { get; set; }
        public int Need { get; set; }
        public int ostatok { get; set; }
    }
}
