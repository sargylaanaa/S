﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarathonSkills
{
    class VolunteerClas
    {
        public int VolunteerId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }
        public string CountryCode { get; set; }

        public string Gender { get; set; }
    }
}
